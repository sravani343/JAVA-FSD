package linearsearch;
import java.util.*;
public class LinearSearch {
	public static void main(String args[]) {
		int n,size,found=0;
		Scanner s=new Scanner(System.in);
		System.out.println("enter the size of the list");
		size=s.nextInt();
		int a[]=new int[size];
		System.out.println("enter" + size +"elements");
		for(int i=0;i<size;i++) {
			a[i]=s.nextInt();
		}
		System.out.println("enter the search element");
		n=s.nextInt();
		for(int i=0;i<size;i++) {
			if(a[i]==n) {
				System.out.println("the element is found at position" + i);
				found=1;
				break;
			}
		}
		if(found==0) {
			System.out.println("the element is not found");
		}
	}
}
	
