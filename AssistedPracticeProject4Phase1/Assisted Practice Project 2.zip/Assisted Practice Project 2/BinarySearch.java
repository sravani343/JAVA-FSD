package binarysearch;

import java.util.Scanner;

public class BinarySearch {

	public static void main(String[] args) {
		int x[] = {2, 3, 4, 5, 10, 12, 56, 67, 90};
		
		System.out.println("Array Values : ");
		for(int n : x)
			System.out.print(n + "  ");
		
		Scanner sc = new Scanner(System.in);
		System.out.println("\nEnter value to search");
		int key = sc.nextInt();
		int first = 0;
		int last = x.length-1;
		int mid = (first+last)/2;
		boolean b = false;
		while(first<=last)
		{
			if(x[mid]==key)
			{
				System.out.println("Value Found...");
				b = true;
				break;
			}
			else if(x[mid]<key)
			{
				first = mid+1;
			}
			else if(x[mid]>key)
			{
				last = mid-1;
			}
			mid = (first+last)/2;
		}
		
		if(b ==false)
			System.out.println("Value not Found");
	}

}
	
	


