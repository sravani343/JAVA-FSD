package bubblesort;
public class BubbleSort {

	public static void main(String[] args) {

		int x[] = {10, 4, 6, 2, 17};
		
		System.out.println("Values Before Sort : ");
		for(int i=0;i<x.length;i++)
		{
			System.out.print(x[i] + "  ");
		}
		
		// Sorting process
		
		for(int i=0;i<x.length;i++)
		{
			for(int j=i+1;j<x.length;j++)
			{
				if(x[i]>x[j])
				{
					int temp = x[i];
					x[i] = x[j];
					x[j] = temp;
				}
			}
		}
		
	
		System.out.println("\nValues After Sort : ");
		for(int i=0;i<x.length;i++)
		{
			System.out.print(x[i] + "  ");
		}

	}

}
