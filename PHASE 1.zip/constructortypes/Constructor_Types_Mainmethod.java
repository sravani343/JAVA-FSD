package constructortypes;
public class Constructor_Types_Mainmethod {
	
	    public static void main(String[] args) {
	        // Testing Default Constructor
	        Myclass defaultObj = new Myclass();
	        System.out.println("Default Constructor - Value: " + defaultObj.getValue());

	        // Testing Parameterized Constructor
	        Myclass paramObj = new Myclass(42);
	        System.out.println("Parameterized Constructor - Value: " + paramObj.getValue());

	        
	    }
	

}

	


