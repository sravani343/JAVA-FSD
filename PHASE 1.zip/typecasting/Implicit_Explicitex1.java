package typecasting;

public class Implicit_Explicitex1 {

	public static void main(String[] args) {
		System.out.println("Implicit Type Casting");
		char a='A';
		System.out.println("Value of a: "+a);
		
		int b=a;
		System.out.println("Value of b: "+b);
		
		float c=a;
		System.out.println("Value of c: "+c);
		
		long d=a;
		System.out.println("Value of d: "+d);
		
		double e=a;
		System.out.println("Value of e: "+e);
		
				
		System.out.println("\n");
		 
		

        // Explicit Type Casting (Narrowing)
        double anotherDoubleValue = 56.74;
        int anotherIntValue = (int) anotherDoubleValue; // Explicit cast from double to int
        System.out.println("Explicit Casting: double to int - Result: " + anotherIntValue);
		

	}

}
