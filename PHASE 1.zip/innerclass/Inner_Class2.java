package innerclass;
public class Inner_Class2 {
		private String msg="Inner Classes";
		
		 void display(){  
			 class Inner{  
				 void msg(){
					 System.out.println(msg);
				 }  
		  }  
		  
		  Inner l=new Inner();  
		  l.msg();  
	 }  

	 
		 public static void main(String[] args) {
			 Inner_Class2 ob=new Inner_Class2 ();  
			ob.display();  
			}
	}


