package oopsconcepts;

public class ClassObject {

	    // Instance Variables
	    String name;
	    String course;
	    int age;
	   
	    // Constructor Declaration of Class
	    public ClassObject(String name, String course,int age)
	    {
	        this.name = name;
	        this.course = course;
	        this.age = age;
	    }
	   
	    
	    public String getName()
	    {
	        return name;
	        
	    }
	    public String getcourse()
	    {
	        return course;
	        
	    }
	    public int getage()
	    {
	        return age;
	        
	    }
	   
	  
	    public static void main(String[] args)
	    {
	        // creating object using new operator
	    	ClassObject s1 = new ClassObject("Ravi","CSE",23);
	        
	        System.out.println("StudentName:"+s1.getName());
	        System.out.println("StudentCourse:"+s1.getcourse());
	        System.out.println("StudentAge:"+s1.getage());
	    }
	

}
