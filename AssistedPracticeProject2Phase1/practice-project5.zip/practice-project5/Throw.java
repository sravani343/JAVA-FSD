package throwthrowsfinally;

public class Throw {
	public static void validate(int age) {
		if(age<18) {
			throw new ArithmeticException("Person is not Eligible to vote");
		}
		else {
			System.out.println(age + " "+ " Age Person is eligible to vote");
		}
	}

	public static void main(String[] args) {
		validate(17);

	}

}
