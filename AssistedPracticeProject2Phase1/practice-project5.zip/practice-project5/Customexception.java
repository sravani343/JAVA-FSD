package throwthrowsfinally;
class customerexception extends Exception 
{ 
public customerexception(String s) 
{ 
    super(s); 
} 
} 
public class Customexception 
{ 
public static void main(String args[]) 
{ 
    try
    { 
        throw new customerexception("temp"); 
    } 
    catch (customerexception ex) 
    { 
        System.out.println("Caught"); 
        System.out.println(ex.getMessage()); 
    } 
} 
}

