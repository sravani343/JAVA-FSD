package oopsinheritance;

public class Inheritance {
	  protected String name;

	  public void display() {
	    System.out.println("I am an employee.");
	  }
	

}
