package oopsabstraction;

abstract class Abstraction {
	    private String name;
	 
	    public Abstraction(String name) { this.name = name; }
	 
	    public abstract void makeSound();
	 
	    public String getName() { return name; }
	}
	 
	 

	 
	