package oopsabstraction;
//Abstracted class
	class Dog extends Abstraction {
	    public Dog(String name) { super(name); }
	 
	    public void makeSound()
	    {
	        System.out.println(getName() + " barks");
	    }
	}