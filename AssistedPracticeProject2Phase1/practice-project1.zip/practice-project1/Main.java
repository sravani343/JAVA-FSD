package threadclass;

public class Main {

	public static void main(String[] args) {
		
		        // Creating a thread by extending the Thread class
		        MyThread thread1 = new MyThread();

		        // Creating a thread by implementing the Runnable interface
		        MyRunnable myRunnable = new MyRunnable();
		        Thread thread2 = new Thread(myRunnable);

		        // Start both threads
		        thread1.start();
		        thread2.start();
		    }


	}


