package trycatch;
public class PracticeProject4 {
	public static void main(String[] args) {
		try {
			int x=40/0; //may throw exception 
		}
		//handling exception by using exception
		catch(Exception e) {
			System.out.println(e);
			}
		System.out.println("canot divide by zero");
		}
	
	}
		

	


