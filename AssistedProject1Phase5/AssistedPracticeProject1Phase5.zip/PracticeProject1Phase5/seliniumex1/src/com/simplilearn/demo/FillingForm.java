package com.simplilearn.demo;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class FillingForm {

	public static void main(String[] args) {
		
				String path="C:\\phase5Selenium\\chromedriver.exe";

				//step:2 set system property
				System.setProperty("webdriver.chrome.driver", path);
				
				//step:3 give base url
				String url="https://www.shine.com/registration/";
				
				//step:4 initiate webdriver
				WebDriver driver= new ChromeDriver();
				
				driver.get(url);
				
				WebElement id_name= driver.findElement(By.id("id_name"));
				//printing an attribute
				System.out.println(id_name.getAttribute("placeholder"));
				
				id_name.sendKeys("nikunji");
				
				
				WebElement email1= driver.findElement(By.id("id_email"));
				//printing an attribute
				System.out.println(email1.getAttribute("placeholder"));
				
				email1.sendKeys("nikun@gmail.com");
				
				WebElement id_cell_phone=driver.findElement(By.id("id_cell_phone"));
				id_cell_phone.sendKeys("9876543208");
				
				
				WebElement password=driver.findElement(By.id("id_password"));
				password.sendKeys("Nikunj@123");
				
                WebElement Continue=driver.findElement(By.name("Continue"));
				
				Continue.click();
				
				
				
	}

}
