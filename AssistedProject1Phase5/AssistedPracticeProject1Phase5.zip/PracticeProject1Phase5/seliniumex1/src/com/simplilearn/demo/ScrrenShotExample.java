package com.simplilearn.demo;

import java.io.File;
import java.io.IOException;

import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.io.FileHandler;


public class ScrrenShotExample {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String path="C:\\phase5Selenium\\chromedriver.exe";

		//step:2 set system property
		System.setProperty("webdriver.chrome.driver", path);

		//step:3 give base url
		String url="https://www.facebook.com/";

		//step:4 initiate webdriver
		WebDriver driver= new ChromeDriver();

		//driver.get(url);
        driver.manage().window().maximize();
		
        driver.get("https://www.amazon.in/");
        
        TakesScreenshot screenshot=(TakesScreenshot) driver;
		File src= screenshot.getScreenshotAs(OutputType.FILE);
		
		try {
			FileHandler.copy(src, new File("C:\\Screenshot//amazon.png"));
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		driver.close();
		

	}

}

//C:\screenshot