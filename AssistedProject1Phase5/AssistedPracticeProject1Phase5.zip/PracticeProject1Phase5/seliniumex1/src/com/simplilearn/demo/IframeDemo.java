package com.simplilearn.demo;

import java.util.List;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class IframeDemo {
	public static void main(String[] args) {
		// TODO Auto-generated method stub
				String path="C:\\phase5Selenium\\chromedriver.exe";

				//step:2 set system property
				System.setProperty("webdriver.chrome.driver", path);
				
				//step:4 initiate webdriver
				WebDriver driver= new ChromeDriver();

				//driver.get(url);
		        driver.manage().window().maximize();
		        
		        driver.get("C:\\htmlexamplephase5\\iframe.html");
				
				driver.manage().timeouts().implicitlyWait(12, TimeUnit.SECONDS);
				
				//find the list of webelements
				List<WebElement> frame=driver.findElements(By.tagName("iframe"));
				
				System.out.println("Total Numbers of Iframes are :"+frame.size());
			
		

	}

}
