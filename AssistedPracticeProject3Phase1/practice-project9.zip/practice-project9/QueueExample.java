package Queue;
import java.util.LinkedList;
import java.util.Queue;

public class QueueExample {
    public static void main(String[] args) {
        // Create a Queue using LinkedList
        Queue<Integer> queue = new LinkedList<>();

        // Insert elements into the queue
        queue.offer(1); // Insert 1 at the rear of the queue
        queue.offer(2); // Insert 2 at the rear of the queue
        queue.offer(3); // Insert 3 at the rear of the queue

        System.out.println("Queue elements: " + queue);

        // Remove elements from the queue (FIFO order)
        int removedElement = queue.poll(); // Remove and return the front element (1)
        System.out.println("Removed element: " + removedElement);
        System.out.println("Queue after removal: " + queue);

        // Peek at the front element without removing it
        int frontElement = queue.peek(); // Peek at the front element (2)
        System.out.println("Front element: " + frontElement);
        System.out.println("Queue after peek: " + queue);
    }
}