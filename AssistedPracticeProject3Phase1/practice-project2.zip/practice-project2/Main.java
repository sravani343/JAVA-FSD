package fourthsmallest;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class Main {
    public static void main(String[] args) {
        List<Integer> myList = new ArrayList<>();
        myList.add(10);
        myList.add(5);
        myList.add(8);
        myList.add(2);
        myList.add(7);

        // Sort the list in ascending order
        Collections.sort(myList);

        // Access the fourth smallest element (index 3)
        int fourthSmallest = myList.get(3);

        System.out.println("The fourth smallest element is: " + fourthSmallest);
    }
}
