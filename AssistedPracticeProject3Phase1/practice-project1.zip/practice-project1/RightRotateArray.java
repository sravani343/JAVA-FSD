package rightrottatearray;

public class RightRotateArray {
	
	    public static void main(String[] args) {
	        int[] originalArray = {1, 2, 3, 4, 5, 6, 7, 8, 9, 10};
	        int rotationSteps = 5;

	        // Create a new array to store the rotated elements
	        int[] rotatedArray = new int[originalArray.length];

	        // Perform the right rotation
	        for (int i = 0; i < originalArray.length; i++) {
	            int newPosition = (i + rotationSteps) % originalArray.length;
	            rotatedArray[newPosition] = originalArray[i];
	        }

	        // Print the rotated array
	        System.out.println("Original Array: ");
	        for (int num : originalArray) {
	            System.out.print(num + " ");
	        }

	        System.out.println("\nRotated Array: ");
	        for (int num : rotatedArray) {
	            System.out.print(num + " ");
	        }
	    }
	}


