package constructortypes;
class Myclass {
	
	    private int value;

	    // Default Constructor
	    public Myclass() {
	        this.value = 0;
	    }

	    // Parameterized Constructor
	    public Myclass(int value) {
	        this.value = value;
	    }

	   
	    public int getValue() {
	        return value;
	    }
	}


	